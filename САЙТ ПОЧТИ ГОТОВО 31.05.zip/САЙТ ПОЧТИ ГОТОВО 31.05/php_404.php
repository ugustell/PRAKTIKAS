<?php
http_response_code(404);
include '404/404.html';
exit;
?>

